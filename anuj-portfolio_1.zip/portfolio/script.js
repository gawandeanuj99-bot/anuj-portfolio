/* =====================================================
   Anuj Gawande | Portfolio behavior
   No libraries, no tracking, no network requests.
   ===================================================== */

/* ---------- YOUR LINKS (edit these three lines) ----------
   Leave a value as "" until you have the real one.
   Examples:
     github:   "https://github.com/your-username"
     linkedin: "https://www.linkedin.com/in/your-profile"
     email:    "you@example.com"
*/
const PROFILE = {
  github: "",
  linkedin: "",
  email: "",
};

(function () {
  "use strict";

  const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ---------- Small helper: toast message ---------- */
  const toast = document.querySelector(".toast");
  let toastTimer;
  function showToast(message) {
    if (!toast) return;
    toast.textContent = message;
    toast.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { toast.hidden = true; }, 3500);
  }

  /* ---------- Placeholder-aware links ----------
     If a real URL exists, the link works normally.
     If not, the link tells the visitor (you!) what to edit instead of going nowhere. */
  function wirePlaceholder(link, label, hint) {
    link.setAttribute("data-placeholder", "true");
    link.removeAttribute("target");
    link.setAttribute("title", hint);
    link.addEventListener("click", function (event) {
      event.preventDefault();
      showToast(hint);
    });
    link.dataset.label = label;
  }

  function applyProfileLinks() {
    document.querySelectorAll("[data-link]").forEach(function (link) {
      const key = link.dataset.link;
      const value = (PROFILE[key] || "").trim();

      if (!value) {
        wirePlaceholder(link, key, "Add your " + key + " in script.js (PROFILE) to activate this link.");
        return;
      }

      if (key === "email") {
        link.href = "mailto:" + value;
        link.removeAttribute("target");
        if (link.hasAttribute("data-show")) link.textContent = value;
      } else {
        link.href = value;
        if (link.hasAttribute("data-show")) link.textContent = value.replace(/^https?:\/\/(www\.)?/, "");
      }
    });
  }

  /* ---------- Project buttons ----------
     Repo / demo URLs come from data-repo / data-demo on each .project-card in index.html. */
  function applyProjectLinks() {
    document.querySelectorAll(".project-card").forEach(function (card) {
      const repo = (card.dataset.repo || "").trim();
      const demo = (card.dataset.demo || "").trim();
      const repoLink = card.querySelector('[data-role="repo"]');
      const demoLink = card.querySelector('[data-role="demo"]');

      if (repoLink) {
        if (repo) {
          repoLink.href = repo;
        } else {
          wirePlaceholder(repoLink, "repository", "Repository link coming soon. Add it with data-repo in index.html.");
        }
      }

      // Live demo only shows when a real demo URL exists
      if (demoLink && demo) {
        demoLink.href = demo;
        demoLink.hidden = false;
      }
    });
  }

  /* ---------- Mobile navigation ---------- */
  const header = document.querySelector(".site-header");
  const navToggle = document.querySelector(".nav-toggle");
  const navMenu = document.getElementById("nav-menu");

  function setMenu(open) {
    navMenu.classList.toggle("is-open", open);
    navToggle.setAttribute("aria-expanded", String(open));
    navToggle.setAttribute("aria-label", open ? "Close menu" : "Open menu");
  }

  if (navToggle && navMenu) {
    navToggle.addEventListener("click", function () {
      setMenu(navToggle.getAttribute("aria-expanded") !== "true");
    });

    // Close after choosing a link
    navMenu.addEventListener("click", function (event) {
      if (event.target.closest("a")) setMenu(false);
    });

    // Escape closes the menu and returns focus to the button
    document.addEventListener("keydown", function (event) {
      if (event.key === "Escape" && navToggle.getAttribute("aria-expanded") === "true") {
        setMenu(false);
        navToggle.focus();
      }
    });

    // Reset when resizing up to desktop layout
    window.matchMedia("(min-width: 52rem)").addEventListener("change", function (event) {
      if (event.matches) setMenu(false);
    });
  }

  /* ---------- Header style + scroll-to-top button ---------- */
  const toTop = document.querySelector(".to-top");

  function onScroll() {
    const y = window.scrollY;
    if (header) header.classList.toggle("is-scrolled", y > 16);
    if (toTop) toTop.hidden = y < 600;
  }
  window.addEventListener("scroll", onScroll, { passive: true });
  onScroll();

  if (toTop) {
    toTop.addEventListener("click", function () {
      window.scrollTo({ top: 0, behavior: prefersReducedMotion ? "auto" : "smooth" });
    });
  }

  /* ---------- Active section highlighting ---------- */
  const navLinks = Array.from(document.querySelectorAll(".nav-link"));
  const sections = navLinks
    .map(function (link) { return document.querySelector(link.getAttribute("href")); })
    .filter(Boolean);

  function setActive(id) {
    navLinks.forEach(function (link) {
      const active = link.getAttribute("href") === "#" + id;
      link.classList.toggle("is-active", active);
      if (active) link.setAttribute("aria-current", "true");
      else link.removeAttribute("aria-current");
    });
  }

  if ("IntersectionObserver" in window) {
    // A section counts as "current" when it crosses the middle band of the screen
    const sectionObserver = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) setActive(entry.target.id);
      });
    }, { rootMargin: "-45% 0px -50% 0px" });
    sections.forEach(function (section) { sectionObserver.observe(section); });
  }

  /* ---------- Reveal on scroll ---------- */
  const revealItems = document.querySelectorAll(".reveal");

  if ("IntersectionObserver" in window && !prefersReducedMotion) {
    const revealObserver = new IntersectionObserver(function (entries, observer) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target); // animate once, then stop watching
        }
      });
    }, { threshold: 0.12 });
    revealItems.forEach(function (item) { revealObserver.observe(item); });
  } else {
    // No observer support or reduced motion: just show everything
    revealItems.forEach(function (item) { item.classList.add("is-visible"); });
  }

  /* ---------- Footer year ---------- */
  const year = document.getElementById("year");
  if (year) year.textContent = new Date().getFullYear();

  /* ---------- Init ---------- */
  applyProfileLinks();
  applyProjectLinks();
})();
