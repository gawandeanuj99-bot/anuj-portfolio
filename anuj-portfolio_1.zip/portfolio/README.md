# Anuj Gawande | Personal Portfolio

A static portfolio built with plain HTML, CSS and JavaScript. No frameworks, no build step, no API keys, no tracking.

```
portfolio/
├── index.html          Page structure and content
├── style.css           All styling (colors, fonts and spacing are variables at the top)
├── script.js           Navigation, scroll effects, link setup
├── assets/
│   └── favicon.svg     Browser tab icon (AG monogram)
└── README.md
```

## Run it locally

Simplest: double-click `index.html`.

Optional local server (nicer for testing):

```
python -m http.server 8000
```

Then open http://localhost:8000.

## Change your name and introduction

- Name: search `index.html` for `Anuj Gawande` and `AG` (monogram) and update each one. Also update the `<title>`, `og:title`, and `author` meta tags near the top.
- Introduction: edit the paragraphs inside `<section id="about">`. The hero text is inside `<section id="home">`.
- Add your college, achievements, or certifications only when they are real. There are `EDIT:` comments marking good spots.

## Add your real links

Open `script.js` and fill in the `PROFILE` object at the top:

```js
const PROFILE = {
  github: "https://github.com/your-username",
  linkedin: "https://www.linkedin.com/in/your-profile",
  email: "you@example.com",
};
```

Every GitHub, LinkedIn and email link on the page (hero, contact, footer) updates automatically. Until you fill these in, clicking them shows a short message instead of going nowhere.

## Projects

Each project is an `<article class="project-card">` in `index.html`.

- Set its repository: `data-repo="https://github.com/you/repo"`
- Set a demo, only if a real one exists: `data-demo="https://..."`. The Live Demo button stays hidden until then.
- To add a project: copy a whole `<article class="project-card ...">` block and edit the title, description, tags, status label (`status-wip` or `status-concept`) and the small SVG illustration (or replace it with an `<img>` that has `alt` text).

## Skills and timeline

- Skills: each skill is one `<li>` in `#skills`. Delete the ones you haven't started; copy one to add another.
- Timeline: each milestone is a `<li class="timeline-item">`. Change the status word (Learning, Exploring, Building, Completed) as you progress.

## Change colors and fonts

At the top of `style.css`, edit the `:root` block: `--accent-blue`, `--accent-violet`, `--accent-cyan`, `--bg`, `--font-sans`, and so on. The site uses system fonts so it makes no external requests. To use a web font, add its `<link>` in `index.html` and put its name first in `--font-sans`.

## Publish online (free)

**GitHub Pages**
1. Create a repository and upload all files, keeping the folder structure.
2. Go to Settings, then Pages. Choose the `main` branch and the `/ (root)` folder, then save.
3. Your site appears at `https://your-username.github.io/repo-name/`.

**Netlify or Cloudflare Pages**: drag the project folder into their dashboard.

After publishing, uncomment and fill in the `og:url` and `og:image` lines in `index.html` so link previews work.

## Contact form

There is intentionally no form. A working form needs a backend or a form service. The email button uses a `mailto:` link, which works without either.
